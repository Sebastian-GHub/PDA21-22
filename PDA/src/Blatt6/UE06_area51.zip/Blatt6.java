package Blatt6;

    public class Blatt6 {
        private static String rowResult = "";
        private static int amountOfRows = 0;
        private static boolean amountOfRowsIsSet = false;
        private static int currentIteration = 5;
        private static boolean invert = false;
        private static final StringBuilder stringBuilder = new StringBuilder();
        public static void main (String[] args) {
            int[] numbers1 = {};
            int[][] numbers2 = {{1,2,3},{1}};
            int[][][]numbers3 =  {{{1, 2}, {3}}, {{4}}};
            System.out.println(arraySum1D(numbers1));
            System.out.println(arraySum2D(numbers2));
            System.out.println(arraySum3D(numbers3));
            System.out.println(average3D(numbers3));
            System.out.println(symmetricDigitSequence(5));
            int[] array = { 2, 4, 1, 3, 7 };
            stepSum(array);
            stepSumRightAligned(array);
            symmetricDigitSequenceRec(5);
            System.out.println(stringBuilder);
        }

        public static int arraySum1D(int[] numbers) {
            int sum = 0;
            for (int i : numbers) {
                sum = sum + i;
            }
            return sum;
        }


        public static int arraySum2D(int[][] numbers) {
            int sum = 0;
            for (int[] i : numbers) {
                sum = sum + arraySum1D(i);
            }
            return sum;
        }

        public static int arraySum3D(int[][][] numbers) {
            int sum = 0;
            for (int[][] i : numbers) {
                sum = sum + arraySum2D(i);
            }
            return sum;
        }

        public static double average3D(int[][][] numbers) {
            double avg = 0;
            int length = 0;
            for (int[][]i : numbers) {
                length++;
            }
            if(length==0) {
                return 0;
            }else {
                avg = (double)(arraySum3D(numbers)/length);
                return avg;
            }

        }

        public static String symmetricDigitSequence(int max) {
            if (max < 0) {
                return "Bitte positive Eingabe";
            }
            int value = max;
            boolean reachedZero = false;
            String result = "";
            for (int i = 0; i<2*max+1 ; i++) {
                result = result+value;
                if(value>0 && !reachedZero) {
                    value = value - 1;
                }else {
                    reachedZero = true;
                    value = value + 1;
                }
            }
            return result;
        }

        public static void stepSum(int[] arr) {
            if (arr.length==1) {
                System.out.println(arr[0]);
            }else {
                int newLength = arr.length;
                int[] newArr = new int[newLength-1];
                for (int i = 0; i<arr.length-1; i++) {
                    newArr[i] = arr[i]+arr[i+1];
                }
                stepSum(newArr);
                for (int i : arr) {
                    System.out.print(i+" ");
                }
                System.out.println();
            }
        }
        public static void stepSumRightAligned(int[] arr) {
            if (!amountOfRowsIsSet) {
                amountOfRows = arr.length * 2;
                amountOfRowsIsSet = true;
            }
            if (arr.length == 1) {
                System.out.printf("%10s", arr[0]);
                System.out.println();

            } else {
                int newLength = arr.length;
                int[] newArr = new int[newLength-1];
                for (int i = 0; i < arr.length - 1; i++) {
                    newArr[i] = arr[i]+arr[i+1];
                }
                stepSumRightAligned(newArr);
                for (int i : arr) {
                    rowResult += i + " ";
                }
                System.out.printf("%11s", rowResult);
                amountOfRows--;
                rowResult = " ";
                System.out.println();
            }
        }
        public static void symmetricDigitSequenceRec(int max) {
            if (currentIteration == 0 && !invert) {
                invert = true;
            }
            stringBuilder.append(currentIteration);

            // Counter
            if (invert) {
                currentIteration++;
            } else {
                currentIteration--;
            }

            // Exit condition
            if (currentIteration > max) {
                return;
            }

            // Executions
            symmetricDigitSequenceRec(max);
        }
    }
